var searchData=
[
  ['value_5ft',['value_t',['../unionvalue__t.html',1,'']]]
];
