var searchData=
[
  ['value_5ftype_5ft',['value_type_t',['../TagV2_8h.html#a188faa13a2e5e9e6514d7ede7b769e1d',1,'TagV2.h']]]
];
