/*
 * Simple HTTPS GET
 */ 
#include <stdio.h>
#include <curl/curl.h>
 
int main(int argc, char **argv)
{
  CURL *curl;
  CURLcode res;
  struct curl_slist *headers = NULL;

  char token[512];
  char url[512];
 

  if(argc < 3) {
    printf("Usage: %s <token> <url>\n", argv[0]);
    return 1;
  }
  sprintf(token, "mx-api-token: %s", argv[1]);
  sprintf(url, "%s", argv[2]);

  curl_global_init(CURL_GLOBAL_DEFAULT);
 
  curl = curl_easy_init();
  if(curl) {
    headers = curl_slist_append(headers, token);
    curl_easy_setopt(curl, CURLOPT_URL, url);

    /* Set headers */
    res = curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
 
    /* Skip the verification of the server's certificate. */
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
 
    /* Skip to verify the certificate's name against host. */
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
 
    /* Perform the request, res will get the return code */ 
    res = curl_easy_perform(curl);
    /* Check for errors */ 
    if(res != CURLE_OK)
      fprintf(stderr, "curl_easy_perform() failed: %s\n",
              curl_easy_strerror(res));
 
    /* always cleanup */ 
    curl_easy_cleanup(curl);
  }
 
  curl_global_cleanup();
 
  return 0;
}
