/*
 * Simple HTTPS GET with write callback
 */ 
#include <stdio.h>
#include <string.h>
#include <curl/curl.h>
 
static size_t my_fwrite(void *buffer, size_t size, size_t nmemb,
                        void *stream)
{
  char *out = (char *)stream;

  memcpy(out, (char *)buffer, (size_t)size*nmemb);
  out[size*nmemb] = 0;

  return nmemb;

  /* default fwrite:
   * return fwrite(buffer, size, nmemb, stdout);
   */
}

int main(int argc, char **argv)
{
  CURL *curl;
  CURLcode res;
  struct curl_slist *headers = NULL;

  char token[512];
  char url[512];
  char response[1024];
 

  if(argc < 3) {
    printf("Usage: %s <token> <url>\n", argv[0]);
    return 1;
  }
  sprintf(token, "mx-api-token: %s", argv[1]);
  sprintf(url, "%s", argv[2]);

  curl_global_init(CURL_GLOBAL_DEFAULT);
 
  curl = curl_easy_init();
  if(curl) {
    headers = curl_slist_append(headers, token);
    curl_easy_setopt(curl, CURLOPT_URL, url);

    /* Set headers */
    res = curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
 
    /* Define our callback to get called when there's data to be written */ 
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, my_fwrite);

    /* Set a pointer to our struct to pass to the callback */ 
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);

    /* Skip the verification of the server's certificate. */
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
 
    /* Skip to verify the certificate's name against host. */
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
 
    /* Perform the request, res will get the return code */ 
    res = curl_easy_perform(curl);
    /* Check for errors */ 
    if(res != CURLE_OK)
      fprintf(stderr, "curl_easy_perform() failed: %s\n",
              curl_easy_strerror(res));
 
    /* always cleanup */ 
    curl_easy_cleanup(curl);

    printf("Response: \n%s\n", response);
  }
 
  curl_global_cleanup();
 
  return 0;
}
